# Alien Phone Emoji (Proposal Submission Files)

**Name:** Alien Phone  
**Category:** Objects / Communication  
**Description:** A friendly green alien on a smartphone screen representing communication across worlds.  
**License:** CC0 1.0 (Public Domain)  
**Author:** [Your Name]  
**Date:** October 2025  

Included files:
- `alien_phone_512.png` – PNG preview (transparent background)
- `alien_phone.meta.json` – metadata for emoji proposal
- `LICENSE.txt` – CC0 license declaration
- `README.md` – summary file
